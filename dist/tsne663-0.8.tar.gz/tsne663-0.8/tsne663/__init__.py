from .sim import make_two_blobs, make_parallel_lines, make_two_3d_circles, make_trefoil_knot, make_springs, perp_plots, step_plots, compare_plots
from .tsne import *